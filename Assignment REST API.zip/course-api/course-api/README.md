# Course API – Express.js + Modular MVC

REST API with **Authentication**, **Category CRUD** and **Course CRUD** (Node.js, Express, MongoDB/Mongoose, JWT).

**Student Name:** ____________  **Roll No / ID:** ____________

## Folder Structure (Modular MVC)
```
server.js                  # entry point (connects DB, starts server)
src/
  app.js                   # express app, routes mounting, 404 + error handler
  config/db.js             # MongoDB connection
  models/                  # M  – User, Category, Course
  controllers/             # C  – business logic
  routes/                  # V/R – URL -> controller (+ validation rules)
  middleware/              # auth (JWT), validate (400/404), errorHandler
  utils/                   # ApiError, asyncHandler
```

## Setup
1. Install Node.js (v18+) and MongoDB (local) **or** use a free MongoDB Atlas URI.
2. `npm install`
3. Copy `.env.example` to `.env` and edit `MONGO_URI` / `JWT_SECRET`.
4. `npm run dev` (or `npm start`) → http://localhost:5000

## Endpoints
| Method | URL | Auth | Description |
|---|---|---|---|
| POST | /api/auth/register | – | Register (name, email, password) → 201 |
| POST | /api/auth/login | – | Login (email, password) → 200 + token |
| GET | /api/auth/me | Bearer | Current user |
| POST | /api/categories | Bearer | Create category (name*, description) → 201 |
| GET | /api/categories | – | List categories → 200 |
| GET | /api/categories/:id | – | Single category |
| PUT | /api/categories/:id | Bearer | Update category |
| DELETE | /api/categories/:id | Bearer | Delete category (blocked if it has courses) |
| POST | /api/courses | Bearer | Create course (title*, description*, price*, category*, duration, level) |
| GET | /api/courses | – | List (filters: `?category=&level=&page=&limit=`) |
| GET | /api/courses/:id | – | Single course |
| PUT | /api/courses/:id | Bearer | Update course |
| DELETE | /api/courses/:id | Bearer | Delete course |

Protected routes need header: `Authorization: Bearer <token>`

## Status codes used
200 OK · 201 Created · 400 Validation error · 401 Unauthorized · 404 Not found (unknown URL / invalid or missing ID) · 409 Duplicate

## Postman Evidence – how to take the 5 screenshots
Set a Postman header `Content-Type: application/json` for all requests.

1. **Register + Login** (two screenshots on one page or two pages)
   - `POST http://localhost:5000/api/auth/register`
     ```json
     { "name": "Ali Khan", "email": "ali@example.com", "password": "123456" }
     ```
     → 201 Created
   - `POST http://localhost:5000/api/auth/login`
     ```json
     { "email": "ali@example.com", "password": "123456" }
     ```
     → 200 OK. Copy the `token`.
2. **POST /api/categories → 201**
   - Headers: `Authorization: Bearer <token>`, `Content-Type: application/json`
   - Body: `{ "name": "Web Development", "description": "Frontend and backend courses" }`
3. **GET /api/categories → 200** (show Headers tab too)
4. **400 Bad Request** – `POST /api/categories` with body `{}` (or `POST /api/auth/register` without `name`) → "Validation failed"
5. **404 Not Found** – `GET http://localhost:5000/api/categories/123` (invalid ID) or `GET http://localhost:5000/api/unknown`

Tip: write your Name + Roll No at the top of each printed page, and make sure the URL bar, method, Headers tab and the response status/body are all visible.
