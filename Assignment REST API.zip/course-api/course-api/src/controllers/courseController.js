const Course = require('../models/Course');
const Category = require('../models/Category');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');

const FIELDS = ['title', 'description', 'price', 'duration', 'level', 'category'];
const pick = (obj) => Object.fromEntries(FIELDS.filter((k) => obj[k] !== undefined).map((k) => [k, obj[k]]));

const ensureCategory = async (id) => {
  if (id && !(await Category.exists({ _id: id }))) throw new ApiError(404, 'Category not found');
};

// POST /api/courses
exports.createCourse = asyncHandler(async (req, res) => {
  await ensureCategory(req.body.category);
  const course = await Course.create({ ...pick(req.body), createdBy: req.user._id });
  await course.populate('category', 'name');
  res.status(201).json({ success: true, message: 'Course created', data: course });
});

// GET /api/courses?category=<id>&level=beginner&page=1&limit=10
exports.getCourses = asyncHandler(async (req, res) => {
  const { category, level, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (category) filter.category = category;
  if (level) filter.level = level;

  const skip = (Math.max(+page, 1) - 1) * Math.max(+limit, 1);
  const [courses, total] = await Promise.all([
    Course.find(filter).populate('category', 'name').sort('-createdAt').skip(skip).limit(+limit),
    Course.countDocuments(filter),
  ]);
  res.status(200).json({ success: true, count: courses.length, total, data: courses });
});

// GET /api/courses/:id
exports.getCourse = asyncHandler(async (req, res) => {
  const course = await Course.findById(req.params.id)
    .populate('category', 'name')
    .populate('createdBy', 'name email');
  if (!course) throw new ApiError(404, 'Course not found');
  res.status(200).json({ success: true, data: course });
});

// PUT /api/courses/:id
exports.updateCourse = asyncHandler(async (req, res) => {
  await ensureCategory(req.body.category);
  const course = await Course.findByIdAndUpdate(req.params.id, pick(req.body), {
    new: true,
    runValidators: true,
  }).populate('category', 'name');
  if (!course) throw new ApiError(404, 'Course not found');
  res.status(200).json({ success: true, message: 'Course updated', data: course });
});

// DELETE /api/courses/:id
exports.deleteCourse = asyncHandler(async (req, res) => {
  const course = await Course.findByIdAndDelete(req.params.id);
  if (!course) throw new ApiError(404, 'Course not found');
  res.status(200).json({ success: true, message: 'Course deleted' });
});
