const { validationResult } = require('express-validator');
const mongoose = require('mongoose');

// Missing / invalid fields -> 400 Bad Request
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map((e) => ({ field: e.path, message: e.msg })),
    });
  }
  next();
};

// Invalid :id -> 404 Not Found
const validateObjectId = (req, res, next) => {
  if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
    return res.status(404).json({ success: false, message: 'Resource not found (invalid ID)' });
  }
  next();
};

module.exports = { validate, validateObjectId };
