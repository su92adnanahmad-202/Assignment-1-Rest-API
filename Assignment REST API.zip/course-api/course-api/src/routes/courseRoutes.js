const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/courseController');
const { protect } = require('../middleware/auth');
const { validate, validateObjectId } = require('../middleware/validate');

const createRules = [
  body('title').trim().notEmpty().withMessage('Title is required'),
  body('description').trim().notEmpty().withMessage('Description is required'),
  body('price').notEmpty().withMessage('Price is required')
    .bail().isFloat({ min: 0 }).withMessage('Price must be a number >= 0'),
  body('category').notEmpty().withMessage('Category is required')
    .bail().isMongoId().withMessage('Category must be a valid ID'),
  body('level').optional().isIn(['beginner', 'intermediate', 'advanced'])
    .withMessage('Level must be beginner, intermediate or advanced'),
];

const updateRules = [
  body('title').optional().trim().notEmpty().withMessage('Title cannot be empty'),
  body('description').optional().trim().notEmpty().withMessage('Description cannot be empty'),
  body('price').optional().isFloat({ min: 0 }).withMessage('Price must be a number >= 0'),
  body('category').optional().isMongoId().withMessage('Category must be a valid ID'),
  body('level').optional().isIn(['beginner', 'intermediate', 'advanced'])
    .withMessage('Level must be beginner, intermediate or advanced'),
];

router.route('/')
  .get(c.getCourses)
  .post(protect, createRules, validate, c.createCourse);

router.route('/:id')
  .get(validateObjectId, c.getCourse)
  .put(protect, validateObjectId, updateRules, validate, c.updateCourse)
  .delete(protect, validateObjectId, c.deleteCourse);

module.exports = router;
