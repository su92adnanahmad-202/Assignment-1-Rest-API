const router = require('express').Router();
const { body } = require('express-validator');
const c = require('../controllers/categoryController');
const { protect } = require('../middleware/auth');
const { validate, validateObjectId } = require('../middleware/validate');

const createRules = [body('name').trim().notEmpty().withMessage('Category name is required')];
const updateRules = [body('name').optional().trim().notEmpty().withMessage('Category name cannot be empty')];

router.route('/')
  .get(c.getCategories)
  .post(protect, createRules, validate, c.createCategory);

router.route('/:id')
  .get(validateObjectId, c.getCategory)
  .put(protect, validateObjectId, updateRules, validate, c.updateCategory)
  .delete(protect, validateObjectId, c.deleteCategory);

module.exports = router;
